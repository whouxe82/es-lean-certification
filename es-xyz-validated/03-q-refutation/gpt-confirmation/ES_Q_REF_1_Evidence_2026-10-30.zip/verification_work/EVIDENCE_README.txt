ES-Q-REF-1 independent confirmation at p = 66361
30 October 2026

RESULT
Q(66361) is false under the frozen mathematical definitions. Universal Q and
the energy draft's residual Conjecture 16 are refuted. The 54 independently
computed reference rows agree exactly. This is a complete Proposition 15
certificate using exhaustive screening plus explicit avoiding allocations.
It is not a new Lean certification, a smallest-counterexample verification,
or an independent reproduction of the entire 25-prime census.

READ FIRST
verification_work/run_001/independent_validation.json
verification_work/run_001/runtime_receipt.json
verification_work/final_logic_note.txt

NUMERICAL EVIDENCE
refutation_certificate.json: complete admissible and firing lists, all 54
explicit avoiding profiles, actual profiles, cells, energies and minima.
exhaustive_screen.json: all 16,658 inputs, factorizations, divisor counts,
histogram hashes, and channel hits. The 16,631 non-firing inputs use the actual
histogram restricted to each eligible cell as the avoiding certificate.
sealed_core_records.json: unchanged optimizer's cell records and allocations.
independent_validation.json: independent reconstruction and witness checks,
Theorem 5 formula comparisons, and the 54-row comparison with the task order.

SOURCE INTEGRITY
The original sealed ZIP is included unchanged. Its 11 manifest-listed files
were checked before and after the main run. The original old census bound
of 13,000 was never altered. The new single-prime adapter checks the newly
authorized input and invokes the unchanged sealed mathematical core.

CHECK THE PROVIDED CERTIFICATE
After extracting this archive, open a terminal in its top-level folder.
The independent checker requires only Python 3.10 or later and the standard
library. It imports no sealed code and calls no optimizer.

python verification_work/independent_validate.py \
  --certificate verification_work/run_001/refutation_certificate.json \
  --output independent_validation_replay.json \
  --reference-docx "upload/ES-Q-REF-1_Task_for_GPT_2026-10-30 1053.docx" \
  --cpu-budget 40

REPLAY THE SEALED MATHEMATICAL CORE
Preserve the supplied run_001 directory before replay, or replay in a copy of
the extracted archive. The adapter uses Linux resource limits and cgroup v2
memory counters as present in the recorded environment. It uses Python 3.10+
and the standard library, and reserves a 180 CPU-second allocation.

python -m zipfile -e \
  verification_work/sources/ES_QP_TEST_GPT_DP_1_0_0_SEALED_2026-10-29.zip \
  verification_work/sealed
python verification_work/run_refutation.py

The deterministic mathematical certificate and screen hashes should agree.
Runtime and validation receipts contain times, paths, and environment details
and are therefore not expected to be byte-identical on another execution.
No network access, repository access, new Lean build, or code change is needed.

PROVENANCE
The user authorized retrieval and the bounded calculation by responding
"Yes proceed" to the explicit request to retrieve the earlier draft and sealed
GPT-DP package and complete the p = 66361 check. The authorization record
preserves this scope; no signature is simulated.

This archive contains the task brief and energy draft, original sealed ZIP,
the new adapter and independent validator, receipts, numerical outputs, and
the final logical assessment. FILE_MANIFEST.json identifies each included
file by SHA-256. The accompanying Word confirmation report is separate.
