#!/usr/bin/env python3
"""ES-Q-REF-1 adapter for the expressly authorized single prime 66361.

Preserves the sealed GPT-DP-1.0.0 module and its old census bound unchanged.
The new task's domain is checked here. The sealed arithmetic/DP functions are
called directly. No reference-table values or firing lists are input to this run.
"""
from __future__ import annotations
import sys
sys.dont_write_bytecode = True
import hashlib, importlib.util, json, math, os, platform, resource, time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

BASE=Path(__file__).resolve().parent
PACKAGE=BASE/'sealed/ES_QP_TEST_GPT_DP_1_0_0'
OUT=BASE/'run_001'
P=66361
VERSION='ES-Q-REF-1-ADAPTER-1.0.0'
CPU_SECONDS=180
EXPECTED_CORE='d5d8ef9f88955fbfe58a2699c796ed393b18d484a772df2d23cf7d6ac50994cf'

def hashfile(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def encoding(obj): return (json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode()
def save(path,obj):
    data=encoding(obj); tmp=path.with_suffix(path.suffix+'.tmp'); tmp.write_bytes(data); tmp.replace(path)
    return hashlib.sha256(data).hexdigest()
def now(): return datetime.now(timezone.utc).isoformat()

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    started=now(); cpu0=time.process_time_ns(); wall0=time.perf_counter_ns()
    receipt={'schema':'ES-Q-REF-1-runtime-1.0','started_utc':started,'adapter_version':VERSION,
             'adapter_sha256':hashfile(__file__),'p':P,'cpu_budget_seconds':CPU_SECONDS,
             'python':sys.version,'platform':platform.platform(),'status':'RUNNING'}
    save(OUT/'runtime_receipt.json',receipt)
    resource.setrlimit(resource.RLIMIT_CPU,(190,195))
    # Less than half currently available cgroup memory, and below five GiB.
    cgroup_max=int(Path('/sys/fs/cgroup/memory.max').read_text())
    cgroup_current=int(Path('/sys/fs/cgroup/memory.current').read_text())
    mem_limit=min(5*1024**3,(cgroup_max-cgroup_current)//2)
    resource.setrlimit(resource.RLIMIT_AS,(mem_limit,mem_limit))
    receipt['memory_limit_bytes']=mem_limit
    def guard():
        if time.process_time_ns()-cpu0 >= CPU_SECONDS*10**9: raise TimeoutError('authorized numerical CPU allocation reached')
    seal=json.loads((PACKAGE/'seal.json').read_text())
    def verify_seal():
        actual={name:hashfile(PACKAGE/name) for name in seal['files']}
        assert actual==seal['files'],'sealed file mismatch'
        assert hashlib.sha256(json.dumps(actual,sort_keys=True,separators=(',',':')).encode()).hexdigest()==seal['file_manifest_sha256']
        return actual
    before=verify_seal()
    assert hashfile(PACKAGE/'es_qp_dp.py')==EXPECTED_CORE
    spec=importlib.util.spec_from_file_location('sealed_es_qp_dp',PACKAGE/'es_qp_dp.py')
    core=importlib.util.module_from_spec(spec); spec.loader.exec_module(core)
    assert core.BOUND==13000
    assert core.VERSION=='GPT-DP-1.0.0'
    core.verify_package()
    receipt['implementation_version']=core.VERSION
    receipt['implementation_sha256']=EXPECTED_CORE
    authorization={
      'schema':'ES-Q-REF-1-current-authorization-record-1.0',
      'scope':'single-prime p=66361 confirmation; no optional primes or repository actions',
      'evidence':{'kind':'user_chat_message','exact_text':'Yes proceed',
                  'responding_to':'May I retrieve the earlier energy-route draft and the GPT-DP-1.0.0 sealed package to complete the bounded p=66,361 confirmation?'},
      'task_order_sha256':hashfile(BASE.parent/'upload/ES-Q-REF-1_Task_for_GPT_2026-10-30 1053.docx'),
      'adapter_sha256':hashfile(__file__),'sealed_core_sha256':EXPECTED_CORE,
      'cpu_budget_seconds':CPU_SECONDS,'whole_task_first_run_limit_seconds':300,
      'signature_note':'Records chat authorization; no signature is simulated.'}
    save(OUT/'authorization_record.json',authorization)
    try:
        assert core.is_prime(P) and P%24==1
        assert P%840 in [1,121,169,289,361,529]
        assert all(q%4==1 for q,e in core.factor(P+1) if q!=2)
        lo=(P+3)//4; hi=3*(P-1)//4
        xs=[x for x in range(lo,hi+1) if pow(x,(P-1)//2,P)==P-1]
        screens=[]; firing=[]; cached={}
        for x in xs:
            guard(); mod=4*x-P
            assert mod>=3 and math.gcd(x,mod)==1 and x<P
            factors=core.factor(x); divs=core.divisors_squared(x,factors)
            bins=Counter(t%mod for t in divs); central=x%mod
            assert bins[central]>0 and bins[central]%2==1
            for r,n in bins.items():
                s=x*x*pow(r,-1,mod)%mod
                assert bins[s]==n
                if r==s and r!=central: assert n%2==0
            tI=-P*x%mod; tII=-x%mod
            assert tI!=tII
            hitI=[a for a in divs if a%mod==tI]
            hitII=[a for a in divs if a%mod==tII]
            screens.append({'x':x,'d':mod,'factorization':factors,'divisor_count':len(divs),
                'histogram_sha256':hashlib.sha256(encoding(sorted(bins.items()))).hexdigest(),
                'channel_I_target':tI,'channel_II_target':tII,
                'channel_I_hits':hitI,'channel_II_hits':hitII,
                'actual_profile_invariants':True})
            if hitI or hitII:
                firing.append(x)
                cached[x]=(mod,factors,divs,bins,tI,tII)
        screen_hash=save(OUT/'exhaustive_screen.json',{'p':P,'interval':{'lo':lo,'hi':hi},'admissible_x':xs,'screens':screens})
        print(json.dumps({'phase':'screen_complete','admissible_x':len(xs),'firing_x':len(firing),'cpu_ns':time.process_time_ns()-cpu0}),flush=True)
        flat=[]; records=[]; core_evidence=[]
        for x in firing:
            guard()
            mod,factors,divs,bins,tI,tII=cached[x]
            H=core.generated_group([q%mod for q,e in factors],mod,guard)
            Hset=set(H); K=sorted({h*h%mod for h in H}); Kset=set(K)
            assert 1 in Kset and Kset<=Hset and set(bins)<=Hset
            # Target cosets are exactly the eligible cells. No noneligible
            # optimization is needed for this explicitly targeted task.
            cosets={}
            for target in (tI,tII):
                if target in Hset:
                    C=sorted({target*k%mod for k in K})
                    assert len(C)==len(K) and set(C)<=Hset
                    cosets[C[0]]=C
            ctx={'p':P,'x':x,'d':mod,'factorization':factors,'divisors':divs,'H':H,'K':K,
                 'cells':[cosets[k] for k in sorted(cosets)],'bins':bins,'central':x%mod,
                 'channel_I_target':tI,'channel_II_target':tII}
            r={'x':x,'d':mod,'factorization':factors,'H_order':len(H),'H_squared_order':len(K),
               'H_sha256':core.sha(core.canonical(H)),'H_squared_sha256':core.sha(core.canonical(K)),
               'channel_I_target':tI,'channel_II_target':tII,'cells':[]}
            evs=[]
            for C in ctx['cells']:
                cell,ev=core.compute_cell(ctx,C,guard)
                assert cell['eligible'] and len(cell['targets'])==1
                channel='I' if tI in cell['targets'] else 'II'
                entry={'x':x,'d':mod,'channel':channel,'T':cell['mass'],'E':cell['energy'],
                       'M':cell['minimum'],'force':cell['force'],'threshold_kind':cell['threshold_kind'],
                       'infinity_reason':cell['infinity_reason'],'cell_id':cell['cell_id'],
                       'target':cell['targets'][0],'residues':C,'actual_sparse_counts':cell['sparse_counts'],
                       'allocation':ev['attaining_sparse_counts'],'H_order':len(H),'H_squared_order':len(K),
                       'allowed_pairs':cell['allowed_pairs'],'allowed_other_fixed':cell['allowed_other_fixed'],
                       'allowed_central':cell['allowed_central']}
                flat.append(entry); r['cells'].append(cell); evs.append(ev)
                save(OUT/'progress.json',{'p':P,'completed_x':x,'cells':flat})
                if cell['force']:
                    save(OUT/'first_unexpected_forcing_cell.json',entry)
                    raise AssertionError('a forcing cell exists; preserve result and stop')
            records.append(r);core_evidence.append({'x':x,'cells':evs})
            print(json.dumps({'phase':'x_complete','x':x,'H_order':len(H),'K_order':len(K),'eligible_cells':len(r['cells']),'cpu_ns':time.process_time_ns()-cpu0}),flush=True)
        flat.sort(key=lambda c:(c['x'],c['channel']))
        math_result={'schema':'ES-Q-REF-1-refutation-certificate-1.0','p':P,
            'admissible_x':xs,'firing_x':firing,'cells':flat,'screen_sha256':screen_hash,
            'sealed_core_sha256':EXPECTED_CORE,'adapter_sha256':hashfile(__file__),
            'frozen_spec_sha256':core.SPEC_HASH,
            'energy_draft_sha256':hashfile(BASE/'sources/ES_Energy_Route_SSRN_Draft_2026-10-29.docx'),
            'screened_certificate_rule':'For each non-firing admissible x and every eligible cell C, use v_C=w_x restricted to C; target absence is exhaustive, and Lemma 1 establishes all profile constraints. Energy equals E_C.',
            'summary':{'admissible_count':len(xs),'firing_count':len(firing),'nonfiring_count':len(xs)-len(firing),
                'explicit_eligible_cells_at_firing_x':len(flat),'forcing_cells':sum(c['force'] for c in flat),
                'equality_cells':sum(c['E']==c['M'] for c in flat),
                'strict_excess_cells':sum(c['E']>c['M'] for c in flat),
                'occupied_channel_rows':sum(dict(c['actual_sparse_counts']).get(c['target'],0)>0 for c in flat),
                'Q_at_p':False,'residual_conjecture_16_counterexample':True},
            'scope_note':'Complete Proposition 15 proof-assisted single-prime certificate. Not a full original RC2 canonical census record; groups/cells at non-firing x are covered by the actual-profile rule.'}
        output_hash=save(OUT/'refutation_certificate.json',math_result)
        save(OUT/'sealed_core_records.json',{'p':P,'x_records':records,'evidence':core_evidence})
        after=verify_seal(); assert before==after and core.BOUND==13000
        receipt.update(status='PASS',output_sha256=output_hash,screen_sha256=screen_hash,
                       sealed_files_unchanged=True,sealed_file_count=len(before),old_bound_unchanged=core.BOUND,
                       numerical_summary=math_result['summary'])
    except Exception as exc:
        receipt.update(status='STOPPED',error_type=type(exc).__name__,error=str(exc))
        raise
    finally:
        receipt.update(ended_utc=now(),cpu_ns=time.process_time_ns()-cpu0,
                       wall_ns=time.perf_counter_ns()-wall0,max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        save(OUT/'runtime_receipt.json',receipt)
        print(json.dumps(receipt,sort_keys=True),flush=True)

if __name__=='__main__': main()
