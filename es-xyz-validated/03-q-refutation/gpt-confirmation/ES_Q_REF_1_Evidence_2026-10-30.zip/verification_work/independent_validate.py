#!/usr/bin/env python3
"""Independent Proposition 15 certificate checker for ES-Q-REF-1.

This script imports no sealed implementation and calls no optimizer.  Its
certificate is a list of explicit avoiding histograms.  It independently
reconstructs the arithmetic domain, divisor histograms, generated groups,
square subgroups and eligible cells, then checks the defining constraints.

Input JSON: {"p": 66361, "cells": [
  {"x": ..., "channel": "I" or "II", "allocation": [[residue,count],...],
   "T": optional_mass, "E": optional_actual_energy,
   "M": optional_claimed_minimum, "cell_id": optional_minimum_residue}
]}.  Optional root-level "firing_x" must match the independently computed
list if supplied.  Unlisted allocation entries are zero.  The checker tests
that allocation energy equals an optional claimed M and independently
evaluates the draft's Theorem 5 formula.  The Proposition 15 refutation
itself needs only feasible energy <= actual energy.
"""

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from math import gcd, isqrt
from pathlib import Path
import platform
import sys
import time
from xml.etree import ElementTree
from zipfile import ZipFile


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def prime_exact(n):
    if n < 2:
        return False
    return all(n % q for q in range(2, isqrt(n) + 1))


def factor_sieve(limit):
    factors = [0] * (limit + 1)
    for q in range(2, limit + 1):
        if factors[q] == 0:
            for m in range(q, limit + 1, q):
                if factors[m] == 0:
                    factors[m] = q
    return factors


def factor_and_squared_divisors(x, least):
    remaining = x
    factors = []
    divisors = [1]
    while remaining > 1:
        q = least[remaining]
        exponent = 0
        while remaining % q == 0:
            remaining //= q
            exponent += 1
        factors.append((q, exponent))
        powers = [q**e for e in range(2 * exponent + 1)]
        divisors = [a * b for a in divisors for b in powers]
    require(len(divisors) == len(set(divisors)), "duplicate squared divisor")
    require(all(x * x % a == 0 for a in divisors), "invalid squared divisor")
    return factors, divisors


def adjoining_cyclic_subgroups(primes, modulus, guard):
    """Build the generated subgroup by adjoining cosets of each generator.

    Starting with an already constructed subgroup G, the successive q^i G
    are distinct until q^i returns to G; their union is <G,q>.  This differs
    from a breadth-first walk on individual residues.
    """
    group = {1}
    for q in primes:
        q %= modulus
        require(gcd(q, modulus) == 1, "nonunit generator")
        if q in group:
            continue
        old_group = group
        extension = set(old_group)
        multiplier = q
        while multiplier not in old_group:
            guard()
            coset = {(g * multiplier) % modulus for g in old_group}
            require(len(coset) == len(old_group), "cyclic coset size")
            require(not (coset & extension), "cyclic coset overlap")
            extension.update(coset)
            multiplier = multiplier * q % modulus
        group = extension
    require(1 in group, "group identity")
    require(all(gcd(h, modulus) == 1 for h in group), "group nonunit")
    for q in primes:
        require(all(h * q % modulus in group for h in group),
                "group not generator-closed")
    return group


def theorem5_minimum(cell, involution, central, target, mass):
    """Evaluate the draft's proved formula from independently counted orbits."""
    removed = {target, involution[target]}
    require(central not in removed, "central target makes avoidance impossible")
    remaining = cell - removed
    central_count = int(central in remaining)
    other_fixed_count = sum(involution[r] == r and r != central for r in remaining)
    pair_count = sum(involution[r] != r for r in remaining) // 2
    dimension = 2 * pair_count + other_fixed_count + central_count
    require(dimension == len(remaining), "remaining orbit count")
    require(mass >= central_count and (mass - central_count) % 2 == 0,
            "avoidance mass feasibility")
    if dimension == 0:
        require(mass == 0, "positive mass without surviving bins")
        minimum = 0
    else:
        units = (mass - central_count) // 2
        q, r = divmod(units, dimension)
        first = min(r, pair_count)
        second = min(max(r - pair_count, 0), other_fixed_count)
        third = max(r - pair_count - other_fixed_count, 0)
        minimum = (central_count + 4 * dimension * q * q + 4 * central_count * q
                   + (8 * q + 2) * first + (8 * q + 4) * second
                   + (8 * q + 6) * third)
    return minimum, {"allowed_pairs": pair_count, "allowed_other_fixed": other_fixed_count,
                     "allowed_central": central_count, "D": dimension}


def reference_rows(docx_path):
    """Read only the first reference table, using standard OOXML parsing."""
    with ZipFile(docx_path) as docx:
        document = ElementTree.fromstring(docx.read("word/document.xml"))
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    table = document.find(".//w:tbl", ns)
    require(table is not None, "missing reference table")
    rows = []
    for row in table.findall("w:tr", ns):
        rows.append(["".join(t.text or "" for t in c.findall(".//w:t", ns)).strip()
                     for c in row.findall("w:tc", ns)])
    require(rows[0] == ["d", "x", "channel", "T", "E", "M", "E < M"],
            "reference table header")
    output = {}
    for d, x, channel, mass, energy, minimum, verdict in rows[1:]:
        key = (int(x), channel)
        require(key not in output, "duplicate reference cell")
        output[key] = {"d": int(d), "T": int(mass), "E": int(energy),
                       "M": int(minimum), "verdict": verdict}
    return output


def verify(certificate, guard, reference=None):
    p = certificate["p"]
    require(type(p) is int and p == 66361,
            "this authorized checker is restricted to p=66361")
    require(prime_exact(p) and p % 24 == 1, "prime-domain requirement")
    low, high = (p + 3) // 4, 3 * (p - 1) // 4
    # Direct construction of all squares independently identifies nonresidues.
    square_residues = {k * k % p for k in range(1, (p + 1) // 2)}
    require(len(square_residues) == (p - 1) // 2, "quadratic residue count")
    admissible = [x for x in range(low, high + 1) if x not in square_residues]
    if "admissible_x" in certificate:
        require(certificate["admissible_x"] == admissible,
                "certificate admissible_x differs from independent complete enumeration")
    least = factor_sieve(high)
    firing = {}
    nonfiring = []
    nonfiring_histogram_digest = hashlib.sha256()
    for x in admissible:
        guard()
        d = 4 * x - p
        require(gcd(x, d) == 1 and d % 4 == 3 and 3 <= d <= 2 * p - 3,
                f"arithmetic invariant x={x}")
        factors, divisors = factor_and_squared_divisors(x, least)
        bins = Counter(a % d for a in divisors)
        targets = {"I": (-p * x) % d, "II": (-x) % d}
        occupied = [ch for ch, target in targets.items() if bins[target] > 0]
        if occupied:
            firing[x] = (d, factors, bins, targets, occupied)
        else:
            # Both targets have zero actual occupancy.  Restricting the actual
            # histogram to any eligible cell is an avoiding profile by the
            # complement involution and its single central integer fixed point.
            # Independently check the global symmetry and parity as well.
            central = x % d
            for r, count in bins.items():
                partner = (x * x * pow(r, -1, d)) % d
                require(bins[partner] == count,
                        f"actual complement mismatch x={x}, r={r}")
                if partner == r:
                    require(count % 2 == (1 if r == central else 0),
                            f"actual fixed-point parity x={x}, r={r}")
            require(bins[central] >= 1 and bins[central] % 2 == 1,
                    f"actual central condition x={x}")
            canonical_histogram = json.dumps(
                [x, sorted(bins.items())], separators=(",", ":")) + "\n"
            nonfiring_histogram_digest.update(canonical_histogram.encode("ascii"))
            nonfiring.append(x)

    if "firing_x" in certificate:
        require(certificate["firing_x"] == sorted(firing),
                "root firing_x differs from independent complete enumeration")

    expected = {}
    arithmetic = {}
    for x, (d, factors, bins, targets, occupied) in firing.items():
        guard()
        group = adjoining_cyclic_subgroups([q for q, e in factors], d, guard)
        squares = {h * h % d for h in group}
        require(1 in squares and squares <= group, f"square subgroup x={x}")
        require(set(bins) <= group, f"divisor residue outside H x={x}")
        require(len(group) % len(squares) == 0, f"subgroup index x={x}")
        for q, e in factors:
            require(all(k * q * q % d in squares for k in squares),
                    f"square subgroup closure x={x}")
        distinct_cells = []
        for channel, target in targets.items():
            if target not in group:
                continue
            cell = {target * k % d for k in squares}
            require(len(cell) == len(squares), f"eligible coset size x={x}")
            require(cell <= group, f"eligible coset membership x={x}")
            require(all(not cell.intersection(old) for old in distinct_cells),
                    f"target separation x={x}")
            distinct_cells.append(cell)
            central = x % d
            involution = {r: x * x * pow(r, -1, d) % d for r in cell}
            require(set(involution.values()) == cell,
                    f"cell complement preservation x={x}, channel={channel}")
            require(all(involution[involution[r]] == r for r in cell),
                    f"cell involution x={x}, channel={channel}")
            for r in cell:
                partner = involution[r]
                require(bins[r] == bins[partner],
                        f"actual symmetry x={x}, channel={channel}, r={r}")
                if partner == r:
                    require(bins[r] % 2 == (1 if r == central else 0),
                            f"actual fixed parity x={x}, channel={channel}, r={r}")
            if central in cell:
                require(bins[central] > 0, f"actual central positivity x={x}")
            mass = sum(bins[r] for r in cell)
            energy = sum(bins[r]**2 for r in cell)
            key = (x, channel)
            expected[key] = (d, target, cell, central, involution, mass, energy)
            arithmetic[key] = {
                "x": x, "d": d, "channel": channel, "target": target,
                "cell_id": min(cell), "cell_size": len(cell),
                "H_order": len(group), "H_squared_order": len(squares),
                "T": mass, "E": energy,
                "actual_target_occupancy": bins[target],
            }

    provided = {}
    require(type(certificate.get("cells")) is list, "missing cells list")
    for row in certificate["cells"]:
        require(type(row["x"]) is int and row["channel"] in ("I", "II"),
                "invalid cell identity")
        key = (row["x"], row["channel"])
        require(key not in provided, f"duplicate certificate cell {key}")
        provided[key] = row
    require(set(provided) == set(expected),
            f"eligible cell coverage; missing={sorted(set(expected)-set(provided))}; "
            f"extra={sorted(set(provided)-set(expected))}")

    validated = []
    for key, row in provided.items():
        guard()
        d, target, cell, central, involution, mass, energy = expected[key]
        require(type(row["allocation"]) is list, f"allocation list {key}")
        allocation = {}
        for entry in row["allocation"]:
            require(type(entry) is list and len(entry) == 2, f"allocation entry {key}")
            r, count = entry
            require(type(r) is int and type(count) is int and count >= 0,
                    f"nonnegative integer allocation {key}")
            require(r in cell and r not in allocation,
                    f"allocation outside cell or duplicate residue {key}, r={r}")
            allocation[r] = count
        require(sum(allocation.values()) == mass, f"avoiding mass {key}")
        require(allocation.get(target, 0) == 0, f"target avoidance {key}")
        for r in cell:
            value = allocation.get(r, 0)
            partner = involution[r]
            require(value == allocation.get(partner, 0), f"avoiding symmetry {key}, r={r}")
            if partner == r:
                if r == central:
                    require(value > 0 and value % 2 == 1,
                            f"avoiding central parity {key}, r={r}")
                else:
                    require(value % 2 == 0, f"avoiding noncentral parity {key}, r={r}")
        avoiding_energy = sum(v * v for v in allocation.values())
        require(avoiding_energy <= energy,
                f"avoiding energy too high {key}: {avoiding_energy}>{energy}")
        formula_minimum, orbit_counts = theorem5_minimum(cell, involution, central, target, mass)
        require(avoiding_energy == formula_minimum,
                f"attained energy differs from Theorem 5 minimum {key}")
        checks = {"T": mass, "E": energy, "M": avoiding_energy,
                  "cell_id": min(cell), "H_order": arithmetic[key]["H_order"],
                  "H_squared_order": arithmetic[key]["H_squared_order"]}
        for field, actual in checks.items():
            if field in row:
                require(type(row[field]) is int and row[field] == actual,
                        f"claimed {field} mismatch {key}: {row[field]} != {actual}")
        if reference is not None:
            require(key in reference, f"unexpected reference row {key}")
            original = reference[key]
            require((d, mass, energy, formula_minimum) ==
                    (original["d"], original["T"], original["E"], original["M"]),
                    f"reference table mismatch {key}")
            require(original["verdict"] == "no" and energy >= formula_minimum,
                    f"reference verdict mismatch {key}")
        validated.append({**arithmetic[key], "avoiding_energy": avoiding_energy,
                          "formula_minimum": formula_minimum, **orbit_counts,
                          "actual_energy_minus_avoiding_energy": energy-avoiding_energy,
                          "profile_constraints": "PASS"})
    validated.sort(key=lambda row: (row["x"], row["channel"]))
    if reference is not None:
        require(set(reference) == set(expected), "reference table coverage mismatch")
    return {
        "p": p, "interval": [low, high], "admissible_count": len(admissible),
        "firing_count": len(firing), "firing_x": sorted(firing),
        "nonfiring_count": len(nonfiring),
        "nonfiring_actual_histograms_sha256": nonfiring_histogram_digest.hexdigest(),
        "nonfiring_histogram_hash_format": "For ascending nonfiring x, concatenate ASCII "
            "JSON [x,[[residue,count],...]] with ascending occupied residues, compact "
            "separators and one newline per x.",
        "nonfiring_certificate": "Actual divisor histogram; both targets zero; "
            "global complement symmetry and fixed-point parity checked exactly. "
            "Restriction to any eligible square-subgroup coset follows Lemma 1.",
        "eligible_cells_at_firing_inputs": len(expected),
        "validated_avoiding_profiles": len(validated),
        "all_eligible_cells_covered": True,
        "Q_p": False,
        "conclusion_basis": "Proposition 15 with explicit avoiding profiles at all firing "
            "inputs and actual-profile certificates at every remaining admissible input",
        "theorem5_formula_crosscheck": "PASS",
        "reference_table_crosscheck": "PASS" if reference is not None else "NOT REQUESTED",
        "minimum_note": "Every attained energy also equals the draft's Theorem 5 formula, "
            "evaluated from independently counted orbits. The refutation itself only needs "
            "the independently verified feasible profiles of energy <= E.",
        "cells": validated,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--certificate", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--cpu-budget", type=float, default=40.0)
    parser.add_argument("--reference-docx")
    args = parser.parse_args()
    cpu0, wall0 = time.process_time(), time.perf_counter()
    started = datetime.now(timezone.utc).isoformat()
    def guard():
        if time.process_time() - cpu0 > args.cpu_budget:
            raise TimeoutError("independent validator CPU budget exceeded")
    result = {
        "checker": "independent_validate.py v1.0",
        "started_utc": started,
        "python_version": platform.python_version(),
        "platform": platform.platform(),
        "checker_sha256": digest(__file__),
        "certificate_path": str(Path(args.certificate).resolve()),
        "certificate_sha256": digest(args.certificate),
        "sealed_module_imported": False,
        "optimizer_called": False,
    }
    status = 0
    try:
        certificate = json.loads(Path(args.certificate).read_text())
        reference = None
        if args.reference_docx:
            result["reference_docx_sha256"] = digest(args.reference_docx)
            reference = reference_rows(args.reference_docx)
        result.update(verify(certificate, guard, reference))
        result["status"] = "PASS"
    except Exception as exc:
        result.update(status="FAIL", error_type=type(exc).__name__, error=str(exc))
        status = 1
    result.update(
        process_cpu_seconds=time.process_time() - cpu0,
        wall_seconds=time.perf_counter() - wall0,
        ended_utc=datetime.now(timezone.utc).isoformat(),
    )
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "cells"}, indent=2, sort_keys=True))
    print("OUTPUT_SHA256 " + digest(output))
    return status


if __name__ == "__main__":
    sys.exit(main())
